package com.hpwellness.sample;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Demo1 
{

	public static void main(String[] args) throws Exception
	{
		// TODO Auto-generated method stub
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\Driver's\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get("https://app.hpswellness.com/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//button[@type='button']")).click();
		//
		
		String sheetName="sheet1";
		int rtcount=0;
		Sheet sh;
		Row row;
		Cell cell; 
		String cellValue;
		Workbook wb;
		ArrayList<String> obj = new ArrayList<>();
		try
		{
		File file = new File("E:\\workspace\\Hpswellness.com\\HpsWellness.xlsx");
		FileInputStream inputStream = new FileInputStream(file);
		wb = new XSSFWorkbook(inputStream);
		sh = wb.getSheet("sheet1");
		rtcount = sh.getLastRowNum();
		
		for(int j=1;j<=2;j++)
		{
		 for(int i=0;i<=10;i++)
		 {
			 //int r1=1;
			 //int i=0;
		 row=sh.getRow(j);
		 cell= row.getCell(i);
		 cellValue = cell.getStringCellValue();
		 obj.add(i,cellValue);
		// r2++;
		 }
		//
		driver.findElement(By.xpath("//input[@id='signup_first_name']")).clear();
		driver.findElement(By.xpath("//input[@id='signup_first_name']")).sendKeys(obj.get(0));
		
		driver.findElement(By.xpath("//input[@id='signup_last_name']")).clear();
		driver.findElement(By.xpath("//input[@id='signup_last_name']")).sendKeys(obj.get(1));
		//Calender
		
		String abc1 = obj.get(2);
		Thread.sleep(1000);
		Select select = new Select(driver.findElement(By.xpath("//div[@class='outer-content']//div[2]//div[2]//div[1]//div[1]//div[1]//select[1]")));
		select.selectByVisibleText(abc1);
		
		driver.findElement(By.xpath("//input[@id='signup_phone']")).clear();
		driver.findElement(By.xpath("//input[@id='signup_phone']")).sendKeys(obj.get(3));
		
		driver.findElement(By.xpath("//input[@id='signup_email']")).clear();
		driver.findElement(By.xpath("//input[@id='signup_email']")).sendKeys(obj.get(4));
				
		driver.findElement(By.xpath("//input[@placeholder='Password*']")).clear();
		driver.findElement(By.xpath("//input[@placeholder='Password*']")).sendKeys(obj.get(5));
				
		driver.findElement(By.xpath("//input[@placeholder='Confirm Password*']")).clear();
		driver.findElement(By.xpath("//input[@placeholder='Confirm Password*']")).sendKeys(obj.get(6));
				
		driver.findElement(By.xpath("//input[@id='signup_city']")).clear();
		driver.findElement(By.xpath("//input[@id='signup_city']")).sendKeys(obj.get(7));
				
		driver.findElement(By.xpath("//input[@id='signup_state']")).clear();
		driver.findElement(By.xpath("//input[@id='signup_state']")).sendKeys(obj.get(8));
				
		String abc = obj.get(9);
		Select select1 = new Select(driver.findElement(By.xpath("//div[@class='row']//div[1]//div[1]//div[1]//div[1]//select[1]")));
		//select1.deselectAll();
		select1.selectByVisibleText(abc);
		
		String xyz = obj.get(10);
		Select select2 = new Select(driver.findElement(By.xpath("//div[@class='outer-content']//div[6]//div[2]//div[1]//div[1]//div[1]//select[1]")));
	//	select2.deselectAll();
		select2.selectByVisibleText(xyz);
	//Check Box		
//				driver.findElement(By.xpath("//input[@value='false']")).click();
	
		
 }
	
		}
		catch(Exception e)
		{
			
		}
				
				
				
	}
}

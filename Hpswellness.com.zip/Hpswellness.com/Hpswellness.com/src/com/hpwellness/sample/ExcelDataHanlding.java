package com.hpwellness.sample;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDataHanlding 
		{
	
	public void readExcel() throws Exception
	{	
		String sheetName="sheet1";
		int rtcount;
		Sheet sh;
		Row row;
		Cell cell; 
		String cellValue;
		ArrayList<String> obj = new ArrayList<>();
		File file = new File("E:\\workspace\\Hpswellness.com\\HpsWellness.xlsx");
	
		FileInputStream inputStream = new FileInputStream(file);
		Workbook wb = null;
		sh = wb.getSheetAt(0);
	 
		
	rtcount = sh.getLastRowNum();
	 
	 for(int i=0;i<=rtcount-1;i++)
	 {
		 int r2=1;
	 row=sh.getRow(r2);
	 cell= row.getCell(i);
	 cellValue = cell.getStringCellValue();
	 obj.add(i,cellValue);
		}
	}
	
			}

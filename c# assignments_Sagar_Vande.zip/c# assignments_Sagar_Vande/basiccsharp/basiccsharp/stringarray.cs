﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
    class stringarray
    {
        string[] charset = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "k ", "l", "m",};
        string s;
        bool b = false;
        public void display()

        {
            Console.WriteLine("Enter any character");

             s = Convert.ToString(Console.ReadLine());

            for (int i = 0; i < charset.Length; i++)

            {

                if (charset[i].Equals(s))

                {

                    b = true;
                }
                
                }
            Console.WriteLine("Char exists in string array?" + b);

            Console.WriteLine("Position of entered character in string is " + Array.IndexOf(charset, s));

            Console.WriteLine("end");
        }
        }
        }

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
    class stringoperations
    {
        string firstname = "Sagar";

        string middlename = "Shamrao";

        string lastname = "Vande";

        string city = "  sangli is my city";

        string dist = "sangli";
        public void strngoperations()
        {
            //join

            string fullname = string.Join("_",firstname,middlename,lastname);


            Console.WriteLine(fullname+"\n");

            //Trim

            string cty = city.Trim();
            Console.WriteLine(cty);

            //split

            string [] cty1 = city.Split();
            
            foreach (string i in cty1)

            {
                Console.WriteLine(i+"\n");

            }

            //TrimEnd

            char[] ch = { 'y' };

            string tstring = city.TrimEnd(ch);

            Console.WriteLine(tstring);


            //TrimStart

            char[] ch1 = { 's' };

            string tstring1 = dist.TrimStart(ch1);

            Console.WriteLine(tstring1);

        }



    }
}

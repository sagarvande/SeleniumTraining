﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
    class Program
    {
        public static void sum()

        {
            int num, sum = 0;

            Console.WriteLine("Enter 10 numbers \n");

            for (int i = 1; i < 11; i++)

            {
                Console.WriteLine("Number : " + i);

                num = Convert.ToInt32(Console.ReadLine());

                sum = sum + num;

            }

            Console.WriteLine("Sum of entered numbers is  " + sum);

        }



        static void Main(string[] args)
        {
            //sum();
            //Day day1 = new Day();
            //day1.displayday();
            //Knowday day2 = new Knowday();
            //day2.showday();
            //Pattern p1 = new Pattern();
            //p1.showpattren();
            //Fibonacci fb1 = new Fibonacci();
            //fb1.displayfib();
            //Reversearray rvr1 = new Reversearray();
            //rvr1.displayreverse();
            //Minmax mxn1 = new Minmax();
            //mxn1.displayMinmax();
            //TwoDarray2onedarray twod = new TwoDarray2onedarray();
            //twod.Convertarray();
            //stringoperations str = new stringoperations();
            //str.strngoperations();
            //Specialchar sp = new Specialchar();
            //sp.display();
            stringarray sg = new stringarray();
            sg.display();


        }
    }
}








﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
    class TwoDarray2onedarray
    {
        public void Convertarray()
        {
            int i, j, m, n,k=0;

            Console.WriteLine("Enter the number of rows for 2d array ");
            m = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the number of Columns for 2d array ");
            n = Convert.ToInt32(Console.ReadLine());

            int[,] arr1 = new int[m, n];

            int [] arr = new int[m * n];

            Console.Write("\n\nRead a 2D array of size mxn and print the matrix :\n");
            Console.Write("------------------------------------------------------\n");


            /* Stored values into the array*/
            Console.Write("Input elements in the matrix :\n");
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    Console.Write("element - [{0},{1}] : ", i, j);
                    arr1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            //Displayed values in 2D array

            Console.Write("\nThe matrix is : \n");
            for (i = 0; i < m; i++)
            {
                Console.Write("\n");
                for (j = 0; j < n; j++)
                    Console.Write("{0}\t", arr1[i, j]);
                Console.WriteLine();

            }

            //Convert from 2D to 1D array
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                    arr[k++] = arr1[i, j];

            }
            //Print converted 1d array

            Console.WriteLine("Converted 1d array is\n");

            for (i = 0; i < m * n; i++)

                
                Console.Write("{0}\t", arr[i]);


            }

        }
            }
    

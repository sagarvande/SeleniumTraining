﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp

{ 
    class Pattern

{

    int i,j,rows;

    public void showpattren()
    {
        Console.WriteLine("Enter no of rows\n");
        rows = Convert.ToInt32(Console.ReadLine());

        for (i = 1; i<=rows; i++)
            {

                for(j=1; j<=i; j++)

                {
                    Console.Write("*");
                    

                }

                Console.WriteLine();
            }

    }
}

}
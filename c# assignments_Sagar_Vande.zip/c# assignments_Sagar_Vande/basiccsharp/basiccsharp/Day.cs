﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
    public class Day
    {
        public static int i;



        public void displayday()
        {
            Console.WriteLine("Enter the number between 1 to 7 to know Day of the week\n");

            i = Convert.ToInt32(Console.ReadLine());

            if (i == 1)
            {
                Console.WriteLine("The day is Monday");
            }
            else if (i == 2)
            {
                Console.WriteLine("The day is Tuesday");

            }

            else if (i == 3)
            {
                Console.WriteLine("The day is Wensday");

            }

            else if (i == 4)
            {
                Console.WriteLine("The day is Thursday");

            }

            else if (i == 5)
            {
                Console.WriteLine("The day is Friday");

            }

            else if (i == 6)
            {
                Console.WriteLine("The day is Saturday");

            }

            else if (i == 7)
            {
                Console.WriteLine("The day is Sunday");

            }

            else
                Console.WriteLine("You have entered wrong value. Please enter correct value");
        }

    }

    public class Knowday
    {
        int count;

        public void showday()
        {

            Console.WriteLine("Enter the number 1 to 7 and know the day of the week\n");

            count = Convert.ToInt32(Console.ReadLine());

            switch (count)
            {
                case 1: Console.WriteLine("The day is Monday");
                    break;
                case 2:
                    Console.WriteLine("The day is Tuesday");
                    break;
                case 3:
                    Console.WriteLine("The day is Wensday");
                    break;
                case 4:
                    Console.WriteLine("The day is Thursday");
                    break;
                case 5:
                    Console.WriteLine("The day is Friday");
                    break;
                case 6:
                    Console.WriteLine("The day is Saturday");
                    break;
                case 7:
                    Console.WriteLine("The day is Sunday");
                    break;
                default:
                    Console.WriteLine("Plese enter value in between 1 to 7");
                    break;
            }
        }

    }
}



﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
    public class Minmax
    {



        int i, max, min;

        // size of the array
       public void displayMinmax()
        {

            int m, n;
            
            Console.Write("Enter the number of array elements ");

            n = Convert.ToInt32(Console.ReadLine());

            int[] arr = new int[n];

            for(int j=0;j<n;j++)
            {
                Console.WriteLine("Element " + j);
                arr[j] = Convert.ToInt32(Console.ReadLine());
            }



      max = arr[0];
      min = arr[0];
      for(i=1; i<n; i++) {
         if(arr[i]>max) {
            max = arr[i];
         }
         if(arr[i]<min) {
            min = arr[i];
         }
      }
      Console.Write("Maximum element = {0}\n", max);
      Console.Write("Minimum element = {0}\n\n", min);
}


    }
}

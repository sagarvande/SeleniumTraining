﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
    class Specialchar
    {
        public string uinput="sdsferwrwtsfsdgt@gtretgfd@rV@nd#@gm@1l";

        string[] spchar ={ "!", "@", "#", "$", "^", "&", "*", "(", ")", " ", "~", "?", "<", ">", "/", "'", "", ".", "₹" };

   public void display()

        {
                for (int i = 0; i < spchar.Length; i++)

            {
               

                    if (uinput.Contains(spchar[i]))

                    {
                        uinput = uinput.Replace(spchar[i], " ");
                    }
             
            }
            Console.WriteLine(uinput);


        }

    }
}

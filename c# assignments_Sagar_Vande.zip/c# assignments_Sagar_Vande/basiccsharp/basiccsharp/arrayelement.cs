﻿using System;
using System.Collections.Generic;
using System.Text;

namespace basiccsharp
{
   public class arrayelement

    {
        static string[] months = { "January", "February", "March", "April", "June", "July", "August", "September", "October", "November", "December" };
        bool b = true;
         bool displayele()
        {
            Console.WriteLine("Enter valid month name");

            string uinput = Convert.ToString(Console.ReadLine());

            int pos = Array.IndexOf(months, uinput);

            if (pos > -1)
            {
                return true;

            }
            else
            {
                return false;
            }

        }
        
    }


}
